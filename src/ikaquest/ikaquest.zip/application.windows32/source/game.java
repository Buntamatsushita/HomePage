import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class game extends PApplet {

//プレイヤー周りの処理
int p_height = 150;
int p_width = 120;
int p_x = width / 10 + p_width + 1;
float p_y = 0.0f; 

boolean shiftKey = false;
boolean jump = false;
int HP = 10;
int score = 0;
boolean down = true;

//画面遷移系の設定
int screenNumber = 0;
int up_count = 0;
int Frame_Rate = 60;
boolean m_click = false;

PImage titleImage;
PImage helpImage;
PImage clearImage;
PImage img;
PImage ebi;
PImage kinoko;
PImage star;


SoundFile clickSound;
SoundFile jumpSound; 
SoundFile kinokoSound;
SoundFile damegeSound;
SoundFile starSound;
SoundFile clearSound;
SoundFile gameoverSound;
SoundFile move1Sound;
SoundFile move2Sound;

//set time
float millisec = 0.0f;
float start_time = 0.0f;
float limit_time = 60.0f;
float show_time = 0.0f;

//set player screen config
int block_size = 60;

ArrayList<Block> block;   //配列を宣言



public void setup() {
    //set screen config
    frameRate(Frame_Rate);
     
    
    //ｘの初期化
    p_y = ((height / 4) * 3) - p_height;
    
    //画像読み込み関係
    titleImage = loadImage("title.png");
    helpImage = loadImage("help.png");
    clearImage = loadImage("clear.png");
    img = loadImage("player.png");  
    ebi = loadImage("ebi.png");
    kinoko = loadImage("kinoko.png");
    star = loadImage("star.png");
    
    block = new ArrayList<Block>(); //ヌルぽ対策
    
    //音源読み込み
    clickSound = new SoundFile(this, "click.mp3");
    jumpSound = new SoundFile(this, "jump.mp3");
    kinokoSound = new SoundFile(this, "kinoko.mp3");
    damegeSound = new SoundFile(this, "damege.mp3");
    starSound = new SoundFile(this, "star.mp3");
    clearSound = new SoundFile(this, "clear.mp3");
    gameoverSound = new SoundFile(this, "gameover.mp3");
    move1Sound = new SoundFile(this, "move1.mp3");
    move2Sound = new SoundFile(this, "move2.mp3");
}

public void draw() {
    //screenNumberの値によって画面遷移
    if (screenNumber == 0) {
        Title();
    } else if (screenNumber == 1) {
        playScreen();
    } else if (screenNumber == 2) {
        GameOverScreen();
    } else if (screenNumber == 3) {
        ClearScreen();
    } else if (screenNumber == 4) {
        helpScreen();
    }
}

public void mouseClicked() {
    if (mousePressed) {
        m_click = true;
    } 
    }
public void drawBlock() {
    ////ブロックを描画
    if (block.size() != 0) {//中身があるか判定
        for (int i = 0; i < block.size(); i++) {
            if (block.get(i).block_style == 0) {   
                image(ebi, block.get(i).block_x, block.get(i).block_y);
            } else if (block.get(i).block_style == 1) { 
                image(star, block.get(i).block_x, block.get(i).block_y);
            } else if (block.get(i).block_style == 2) {   
                image(kinoko, block.get(i).block_x, block.get(i).block_y);
            } else {
                if (block.get(i).block_x < - 90) {
                    block.remove(i);
                } else {
                    rect(block.get(i).block_x, block.get(i).block_y, block_size, block_size);
                }
            } 
        }
    }
}

class Block {
    ////流れてくるオブジェクト用のクラス
    int block_x, block_y, block_style;
    Block(int block_x, int block_y, int block_style) {
        this.block_x = block_x;
        this.block_y = block_y;
        this.block_style = block_style;   //ブロックの仕様設定用
    }
    
}

public void makeBlock() {
    ////ブロックを生成
    if (block.size() != 0) {  //中身があるか判定
        for (int i = 0; i < block.size(); i++) {    
            block.get(i).block_x -= 2;  //要素のｘ値を変更
        }
    }
    if (frameCount % 60 == 0) {  //約1秒に1回生成
        int ramdom = PApplet.parseInt(random(7));   //ランダムで0-7の数字を生成
        if (ramdom > 2 && ramdom <= 7) { //3-7 はお邪魔ブロック　　偶数下記数で表示するy値を管理
            if (ramdom % 2 == 0) {
                block.add(new Block(width - block_size,(((height / 4) * 3) - block_size), 3));
            } else {
                block.add(new Block(width - block_size,(((height / 4) * 3) - (block_size * 2)), 4));
            }
        } else if (ramdom == 2) {//毒キノコ生成
            block.add(new Block(width - block_size,(((height / 4) * 3) - 51), 2));
        } else if (ramdom == 1) {//スター生成
            block.add(new Block(width - block_size,(((height / 4) * 3) - p_height - 100), 1));
        } else if (ramdom == 0) {//エビ生成
            block.add(new Block(width - block_size,(((height / 4) * 3) - 150), 0));
        }
        
    }
}

public int hitcheck(int p_x, float p_y, int p_width, int p_height,int b_x, int b_y,int b_height, int b_width) {
    ////お邪魔ブロックのどの側面にあるかを判定
    if (HitCheck(p_x, p_y, p_width, p_height, b_x, b_y, b_height, b_width)) {
        if ((b_x - 20 < p_x + p_width) && (b_x + 10 > p_x + p_width)) {
            return 3; 
        } else if ((b_x + b_width > p_x) && (b_x + 20 < p_x)) {
            return 4; 
        } else if ((p_y + p_height) > b_y - 1) {
            return 1;
        } else if (p_y < b_height + b_y + 20) {
            return 2; 
        }  else {
            return 10;
        }
    } else {
        return 0;
    }
    
} 

public boolean HitCheck(int p_x, float p_y, int p_width, int p_height, int b_x, int b_y,int b_height, int b_width) {
    ////当たっているか判定
    return p_x < b_x + b_width && b_x < p_x + p_width && p_y < b_y + b_height && b_y < p_y + p_height;
} 

public void blockHitCheck() {
    ////オブジェクトとの判定を管理
    for (int i = 0; i < block.size(); i++) {
        if (block.get(i).block_style == 0) {
            boolean flag = HitCheck(p_x, p_y, p_width, p_height, block.get(i).block_x, block.get(i).block_y, 50,50);
            if (flag) {
                block.remove(i);
                if (HP < 10) {
                    HP += 1;
                }
            }
        } else if (block.get(i).block_style == 2) {
            boolean flag = HitCheck(p_x, p_y, p_width, p_height, block.get(i).block_x, block.get(i).block_y, 50,50);
            if (flag) {
                block.remove(i);
                kinokoSound.play();
                HP -= 2;
            }
        } else if (block.get(i).block_style == 1) {
            boolean flag = HitCheck(p_x, p_y, p_width, p_height, block.get(i).block_x, block.get(i).block_y, 50,50);
            if (flag) {
                block.remove(i);
                starSound.play();
                score += 100;
            }
        } else {
            int flag = hitcheck(p_x, p_y, p_width, p_height, block.get(i).block_x, block.get(i).block_y, block_size, block_size);
            ///hitcheck関数に投げて返ってきた値によって操作をする
            if (flag == 1 && jump == false) {
                p_y = block.get(i).block_y - 150;
                down = false;
            } else if (flag == 2) {
                p_y = block.get(i).block_y + 60;
                down = true;
            } else if (flag == 3) {
                p_x = block.get(i).block_x - p_width;
                down = true;
            } else if (flag == 4) {
                p_x = block.get(i).block_x + block_size;
                down = true;
            } else if (p_y + p_height - 4 != block.get(i).block_y) {
                down = true;
            }
        }
    }
}
public void GameOverScreen() {
    background(0);

    fill(255,0, 0);
    textSize(130);
    text("GAME OVER",115,250);

    fill(255);
    textSize(50);
    text("score:" + str(score), 380 ,400);
    text("- - - ENTER TO CONTINUE - - -",115,500);
    text("- - - BACKSPACE TO TITLE - - -",115,600);

    if (keyPressed) {
        ///キー入力があった時の処理関係
        if (keyCode == ENTER) {
            ///Enterの場合
            screenNumber = 1;
            HP = 10;
            score = 0;
            start_time = millis();
            block.clear();
            p_x = width / 10 + p_width + 1;
        } else if (keyCode == BACKSPACE) {
            ///Backspaceの場合
            screenNumber = 0;
        }
    }
}

public void ClearScreen() {
    ////クリア画面の表示
    mouseClicked();
    image(clearImage,0,0);
    
    fill(255);
    textSize(50);
    text("SCORE:" + str(score),360,390);
    if (m_click) {
        ///クリックがあった時の処理関係
        m_click = false;
        screenNumber = 0;
        start_time = millis();
    }
}
public void Title() {
    ////タイトル画面の描画
    mouseClicked();         //マウスクリックがあるか
    image(titleImage,0,0);  //タイトル画面の描画
    if (m_click) {
        ///クリックがあった場合の処理関係
        clickSound.play();  //効果音
        m_click = false;    //判定を元に戻す
        screenNumber = 1;   //画面をプレイ画面へ遷移
        start_time = millis();  //スタート時間を記録
        //諸々をリセット
        HP = 10;
        score = 0;
        p_x = width / 10 + p_width + 1;
        block.clear();
        frameRate(60);
    }
    if (keyPressed) {
        ///キー入力があった時の処理関係
        if (keyCode == ENTER) {
            screenNumber = 4;
            move1Sound.play();
            frameRate(10);
        }
    }  
    
}

public void helpScreen() {
    
    ////ヘルプ画面の描画
    mouseClicked();         //マウスクリックがあるか
    image(helpImage, 0, 0);
    if (m_click) {
        ///クリックがあった場合の処理関係
        move2Sound.play();  //効果音
        m_click = false;    //判定を元に戻す
        screenNumber = 0;   //画面をタイトル画面へ遷移
        frameRate(60);
    }
}
public void playScreen() {
    //時間を取得　1/1000
    millisec = millis();
    
    

    //背景の設定
    background(0, 229, 255);
    fill(251,231,172);
    rect(0,(height / 4) * 3, width, height / 4);
    fill(200);
    rect(0, 0, width / 10, ((height / 4) * 3));
    
    //プレイヤーを描画する関係
    checkShiftKey();
    p_keyPressed();
    fill(255);
    drawBlock();
    drawPlayer();
    time();
    Score();
    makeBlock();

    //ダメージゾーン
    fill(255, 0 , 0, 130);
    rect(0, 0, width / 10, ((height / 4) * 3));

    //ブロックとの接触判定
    blockHitCheck();

    //描画系　関数たち
    HPdraw();
    damege();
    if (HP <= 0) {
        gameoverSound.play();
        screenNumber = 2;
    }
}



public void time() {
    //時間を管理
    show_time = limit_time - ((millisec - start_time) / 1000) + 1;
    textSize(20);
    fill(0);
    String tmp = "time:" + str(PApplet.parseInt(show_time));
    text(tmp ,900,20);
    if (show_time <= 0.9f) {
        screenNumber = 3;
        clearSound.play();
        millisec = 0.0f;
        frameRate(10);
    } 
}

public void Score(){
    //スコアの表示
    String tmp = "score:" + str(score);
    textSize(20);
    text(tmp, 900, 40);
}

public void HPdraw(){
    //HPの表示
    textSize(30);
    text("HP",(width/4)*2 - 40, 27);
    rect((width/4)*2, 0, 202, 32);
    fill(255,20,147);
    rect((width/4)*2 + 1, 1, HP * 20 + 1, 30);
}
public void checkShiftKey() {
    /////shift入力があるか判定
    if (shiftKey){
        fill(0);
        textSize(15);
        text("DASH MODE",100,15);
    }
    if (keyPressed) {
        if (key == CODED) {
            if (keyCode == SHIFT) {
                if (shiftKey == false) {
                    shiftKey = true;
                }
            } else if (keyCode == CONTROL) {
                shiftKey = false;
            }
        }
    }
}

public void p_keyPressed() {
    ////操作関係
    fill(0);
    if (keyPressed) {
        if (key == CODED) {
            if (shiftKey == true) {
                if (keyCode == UP) {
                    if (up_count <= 0 && p_y > ((height / 4) * 3) - (p_height * 2.5f)) {
                        jumpSound.play();
                        up_count += Frame_Rate * 3;
                        jump = true;
                    }
                }
                else if (keyCode == LEFT) {
                    p_x = p_x - 6;
                }
                else if (keyCode == RIGHT) {
                    p_x = p_x + 6;
                }  
            } else{
                if (keyCode == UP) {
                    if (up_count <= 0 && p_y > ((height / 4) * 3) - (p_height * 2.5f)) {
                        jumpSound.play();
                        up_count += Frame_Rate * 2;
                        jump = true;
                    }
                }
                else if (keyCode == LEFT) {
                    p_x = p_x - 4;
                }
                else if (keyCode == RIGHT) {
                    p_x = p_x + 4;
                }  
            }
        }
    }
}


public void drawPlayer() {
    ////プレイヤーを描画する
    ///重力関係
    if (jump && p_y > ((height / 4) * 3) - (2.1f * p_height)) {
        p_y -= 4.0f;
    } else if (jump && p_y <= ((height / 4) * 3)) {
        jump = false;
    } else if (down) {
        p_y += 4.0f;
    }
    
    up_count -= 2; //ジャンプ制限時間管理
    
    if (p_y >= ((height / 4) * 3) - p_height) {
        p_y = ((height / 4) * 3) - p_height;
    }
    if (p_x >= width - p_width) {
        p_x = width - p_width;
    } else if (p_x < 0) {
        p_x = 0;
    }
    
    image(img, p_x, p_y);  //描画
}

public void damege() {
    ////ダメージゾーンの処理
    if (p_x < width / 10 && frameCount % 80 == 0) {
        damegeSound.play();
        HP -= 1;
        fill(255,0,0,150);
        rect(0,0,width,height);
    }
}
  public void settings() {  size(1000,700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "game" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
